director_frob

foo = Bravo();
s = foo.abs_method();

if (!strcmp(s,"Bravo::abs_method()"))
  error(s)
endif

