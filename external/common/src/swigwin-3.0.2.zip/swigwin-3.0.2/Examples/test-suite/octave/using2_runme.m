using2

if (using2.spam(37) != 37)
    error
endif
