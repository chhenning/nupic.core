abstract_typedef2

a = A_UF();
  




