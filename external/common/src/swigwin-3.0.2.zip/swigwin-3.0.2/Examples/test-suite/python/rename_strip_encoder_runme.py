from rename_strip_encoder import *

s = SomeWidget()
a = AnotherWidget()
a.DoSomething()

