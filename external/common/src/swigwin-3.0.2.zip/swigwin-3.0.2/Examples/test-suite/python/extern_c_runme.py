import extern_c

extern_c.RealFunction(2)

