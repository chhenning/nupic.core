import cpp11_initializer_list

a = cpp11_initializer_list.A()
a = cpp11_initializer_list.A(11.1)

