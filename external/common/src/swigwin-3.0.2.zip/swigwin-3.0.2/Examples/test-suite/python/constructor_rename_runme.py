from constructor_rename import *

x = RenamedConstructor()
