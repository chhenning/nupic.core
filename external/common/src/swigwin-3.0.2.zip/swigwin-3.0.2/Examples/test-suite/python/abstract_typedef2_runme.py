from  abstract_typedef2 import *

a = A_UF()
  




